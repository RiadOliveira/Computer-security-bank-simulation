package components.appClient;

public enum ClientLocalOperation {
  CLEAR_CONSOLE, EXIT
}
