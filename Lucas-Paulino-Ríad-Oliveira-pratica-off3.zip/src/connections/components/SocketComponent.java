package connections.components;

public enum SocketComponent {
  CLIENT, FIREWALL, GATEWAY,
  AUTHENTICATION_SERVICE, BANK_SERVICE,
  BANK_DATABASE
}
